﻿namespace VRTK.Examples.Scarecrow.Tags
{
    using UnityEngine;

    public class ScarecrowHatTag : MonoBehaviour
    {
    }
}