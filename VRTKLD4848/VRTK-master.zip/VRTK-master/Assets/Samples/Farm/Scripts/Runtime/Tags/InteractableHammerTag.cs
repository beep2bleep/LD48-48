﻿namespace VRTK.Examples.Tags
{
    using UnityEngine;

    public class InteractableHammerTag : MonoBehaviour
    {
    }
}